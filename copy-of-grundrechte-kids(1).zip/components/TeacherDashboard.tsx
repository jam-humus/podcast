// This file is no longer used in the standalone Podcast Workshop version.
// It can be deleted.
export const TeacherDashboard = () => <div>Teacher Dashboard Removed</div>;
